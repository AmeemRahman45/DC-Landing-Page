window.addEventListener('DOMContentLoaded', () => {
    const bgMusic = document.getElementById('backgroundMusic');
    bgMusic.volume = 0.2; // Gentle background volume
  });

  document.addEventListener('click', () => {
    const bgMusic = document.getElementById('backgroundMusic');
    if (bgMusic.paused) {
      bgMusic.play();
    }
  });
  