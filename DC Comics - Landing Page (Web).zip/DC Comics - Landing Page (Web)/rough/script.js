document.addEventListener("DOMContentLoaded", () => {
    const heroes = [
      { name: "Superman", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Superman_5c3fc2758f6984.90100206.jpg" },
      { name: "Batman", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Batman_20190116_5c3fc4b40fae42.85141247.jpg" },
      { name: "Wonder Woman", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_WonderWoman_20190116_5c3fc6aa51d064.76155401.jpg" },
      { name: "The Flash", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Flash_20190116_5c3fcaaa18f023.90325986.jpg" },
      { name: "Green Lantern", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_GreenLantern_20200721_5f173ac65f56f7.70929296.jpg" },
      { name: "Aquaman", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Aquaman_5c411a95e70ff5.50429372.jpg" },
      { name: "Cyborg", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Cyborg_20190116_5c3fcd9048a0e1.41912254.jpg" },
      { name: "Green Arrow", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_GreenArrow_5c4915494b3fb9.17530021.jpg" },
      { name: "Supergirl", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Supergirl_5b6b48c92a5d42.10749263.jpg" },
      { name: "Martian Manhunter", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_MartianManhunter_20190116_5c3fd5c45bcd52.92066763.jpg" },
      { name: "Hawkgirl", img: "https://static.dc.com/dc/files/default_images/Char_Profile_Hawkgirl_20190116_5c3fd4bc7fd114.15903111.jpg" },
      { name: "Zatanna", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Zatanna_5c5a3dd6b811f3.85644553.jpg" },
      { name: "Shazam", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Shazam_5c53a74aefbb12.02099042.jpg" },
      { name: "Nightwing", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Nightwing_2_5c50fa380942a3.78305981.jpg" },
      { name: "Batgirl", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Batgirl_5c410fd9aa14d0.53215721.jpg" },
      { name: "Black Canary", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_BlackCanary_5c41184e20ee69.98463239.jpg" },
      { name: "Blue Beetle", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_BlueBeetle_5c4118a71474e2.43949452.jpg" },
      { name: "Stargirl", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Stargirl_5eb4a5cd5ccaf7.93430787.jpg" },
      { name: "Raven", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Raven2_5c525571ef82a6.09738300.jpg" },
      { name: "Beast Boy", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_BeastBoy_5c411282c5c040.32747717.jpg" },
      { name: "Starfire", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Starfire_5f861a27cdb0f2.50441655.jpg" },
      { name: "Constantine", img: "https://static.dc.com/dc/files/default_images/constantine_192x291_53c5878ac85f71.24976215.jpg" },
      { name: "Doctor Fate", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_DoctorFate_6347343a407578.59680601.jpg" },
      { name: "Booster Gold", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_BoosterGold_5c411938e61ab5.56452822.jpg" },
      { name: "Swamp Thing", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_SwampThing_5c5a3849d9a622.19853178.jpg" },
      { name: "Harley Quinn", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_HarleyQuinn_5c4a3e758122a3.39576701.jpg" },
      { name: "Catwoman", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Catwoman_5c47c984ed1bf1.93808647.jpg" },
      { name: "Huntress", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Huntress__5e1e75ba8a0478.82655987.jpg" },
      { name: "Red Hood", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_RedHood_5f20be014954a5.16447111.jpg" },
      { name: "Robin (Damian Wayne)", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Robin_5c5c888fd675e4.98555002.jpg" },
      { name: "Poison Ivy", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_PoisonIvy_5c5252e46f2247.19314178.jpg" },
      { name: "Bane", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Bane_5c410f07428e44.78856363.jpg" },
      { name: "Lex Luthor", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_LexLuthor_5c4a62d2862528.01646688.jpg" },
      { name: "Joker", img: "https://static.dc.com/dc/files/default_images/Char_Thumb_Joker_5c4a42b7ef2011.52750480.jpg" }
    ];
  
    const heroBiographies = {
      "Superman": "Born on Krypton as Kal-El, he was raised on Earth and fights for truth and justice.",
      "Batman": "After witnessing his parents' death, Bruce Wayne became Gotham's vigilante detective.",
      "Wonder Woman": "Diana of Themyscira is an Amazon warrior and ambassador of peace.",
      "The Flash": "Barry Allen uses his super speed to protect Central City and the timeline.",
      "Green Lantern": "Hal Jordan is part of an intergalactic police force wielding a powerful ring.",
      "Aquaman": "Arthur Curry is the half-human king of Atlantis and a Justice League founder.",
      "Cyborg": "Victor Stone is enhanced with advanced alien technology after a lab accident.",
      "Green Arrow": "Billionaire Oliver Queen fights crime with his archery and trick arrows.",
      "Supergirl": "Kara Zor-El, Superman’s cousin, protects Earth with similar Kryptonian powers.",
      "Martian Manhunter": "J’onn J’onzz is a shapeshifting Martian with telepathy and super strength.",
      "Hawkgirl": "A fierce warrior with wings and a mace, often linked to ancient Egypt.",
      "Zatanna": "A stage magician and real sorceress who casts spells by speaking backwards.",
      "Shazam": "Billy Batson becomes a magic-powered adult superhero by shouting 'Shazam!'",
      "Nightwing": "Dick Grayson, the original Robin, strikes out on his own as Nightwing.",
      "Batgirl": "Barbara Gordon fights crime in Gotham with brains, gadgets, and martial skill.",
      "Black Canary": "Dinah Lance is a martial artist with a sonic scream called the Canary Cry.",
      "Blue Beetle": "Jaime Reyes is fused with an alien scarab that gives him a high-tech suit.",
      "Stargirl": "Courtney Whitmore uses the Cosmic Staff to battle evil with youthful optimism.",
      "Raven": "Daughter of a demon, she uses empathic and mystical powers to fight darkness.",
      "Beast Boy": "Gar Logan can transform into any animal and is known for his humor.",
      "Starfire": "A powerful alien princess who can fly and shoot energy bolts.",
      "Constantine": "A cynical occult detective and magician who battles demons and the supernatural.",
      "Doctor Fate": "Wears the mystical Helmet of Nabu and channels vast magical power.",
      "Booster Gold": "A fame-hungry hero from the future who uses advanced tech to fight crime.",
      "Swamp Thing": "A plant elemental guardian who protects the natural world.",
      "Harley Quinn": "Former psychiatrist turned chaotic anti-hero with acrobatic skills.",
      "Catwoman": "A stealthy cat burglar with a complicated relationship with Batman.",
      "Huntress": "A vigilante who uses crossbows and vengeance to clean Gotham’s streets.",
      "Red Hood": "Jason Todd, once Robin, now an anti-hero with a deadly edge.",
      "Robin (Damian Wayne)": "Son of Batman and Talia al Ghul, trained by the League of Assassins.",
      "Poison Ivy": "A botanical genius and eco-terrorist with plant control abilities.",
      "Bane": "A mastermind with immense strength, fueled by the drug Venom.",
      "Lex Luthor": "Superman's brilliant nemesis driven by ego, intellect, and ambition.",
      "Joker": "Batman’s chaotic and sadistic arch-enemy, the Clown Prince of Crime."
    };
  
    const container = document.getElementById("cards-container");
    const modal = document.getElementById("modal");
    const modalName = document.getElementById("modalName");
    const modalBio = document.getElementById("modalBio");
    const closeModal = document.getElementById("closeModal");
    const hoverSound = document.getElementById("hoverSound");
  
    heroes.forEach(hero => {
      const card = document.createElement("div");
      card.className = "card fade-in";
      card.innerHTML = `<img src="${hero.img}" alt="${hero.name}"><h3>${hero.name}</h3>`;
  
      card.addEventListener("click", () => {
        modalName.textContent = hero.name;
        modalBio.textContent = heroBiographies[hero.name] || "Biography not available.";
        modal.style.display = "flex";
      });
  
      card.addEventListener("mouseenter", () => {
        hoverSound.currentTime = 0;
        hoverSound.play();
      });
  
      container.appendChild(card);
    });
  
    closeModal.addEventListener("click", () => {
      modal.style.display = "none";
    });
  
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    }, { threshold: 0.1 });
  
    document.querySelectorAll(".fade-in").forEach(el => observer.observe(el));
  });
  